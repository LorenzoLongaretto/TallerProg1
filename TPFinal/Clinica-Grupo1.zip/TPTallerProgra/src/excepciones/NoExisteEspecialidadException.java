package excepciones;

public class NoExisteEspecialidadException extends ImposibleCrearMedicoException{

	public NoExisteEspecialidadException(String msj, String dato) {
		super(msj, dato);
		
	}

	

}
