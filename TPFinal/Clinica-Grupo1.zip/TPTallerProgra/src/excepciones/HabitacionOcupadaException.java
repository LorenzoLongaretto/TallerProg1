package excepciones;

public class HabitacionOcupadaException extends Exception{
     
	public HabitacionOcupadaException(String msj) {
		super(msj);
		
	}
          
}
